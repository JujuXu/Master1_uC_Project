#ifndef _TIMERS_H_
#define _TIMERS_H_


//DEFINE


//PROTOTYPE FONCTIONS EXTERNES
// Configuration du TIMER pour g�n�rer une interruption toutes les 1mS
// On utilise le mode Overflow.
void TIMER1_Init_1ms(void);
void TIMER0_Init_1ms(void);


#endif 
