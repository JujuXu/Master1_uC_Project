#ifndef _HARDWARE_H_
#define _HARDWARE_H_

//DEFINE

//PROTOTYPE FONCTIONS EXTERNES
void Init_Hardware(void);

#endif 